# Research

## Qu'est-ce que la science et la recherche

La science est un examen rigoureux du monde qui nous entoure. La science consiste à poser des questions, à faire des observations et à évaluer les idées qui en découlent. En d'autres termes, la science vise à poser des questions de recherche et à concevoir des études qui peuvent répondre à ces questions. 
**La science est systématique, transparente, explicite et reproductible.**

Il existe plusieurs définitions de la recherche. Creswell (2002, p. 3) en suggère une qui est simple à comprendre : **La recherche est un « processus d'étapes utilisées pour recueillir et analyser des renseignements afin d'accroître notre compréhension d'un sujet ou d'un enjeu »**.

Les deux types de recherche dont on entend souvent parler sont la recherche fondamentale et la recherche appliquée.

Recherche fondamentale | Recherche appliquée |
| ------------- |-------------|
| Conduit pour faire progresser les connaissances fondamentales sur le monde. Il s'agit parfois d'une recherche en laboratoire ou sur banc d'essai | Se concentre sur l'analyse et la résolution de problèmes réels (p. ex. découvrir l'efficacité d'un médicament particulier). |


## Recherche axée sur le patient
Un **patient** est une personne qui a une expérience personnelle d'un problème de santé, y compris les aidants naturels, et l'un des principaux centres d'intérêt des Instituts de recherche en santé du Canada (IRSC) au cours des dernières années est **la recherche axée sur le patient**.

**Recherche orientée vers le patient:**

* Il s'agit de faire participer les patients, leurs soignants et leur famille en tant que partenaires.
* Cible les priorités identifiées par les patients et améliore les résultats pour la santé
* Est dirigé par des équipes multidisciplinaires en partenariat avec différentes parties prenantes
* Vise à appliquer les connaissances générales pour améliorer les systèmes et les pratiques de soins de santé.

><a href="http://www.cihr-irsc.gc.ca/f/41204.html" target="_blank">La recherche axée sur le patient a pour but de mobiliser les patients, les soignants et les familles à titre de partenaires dans le processus de recherche. Cet engagement aide à garantir que les études sont axées sur les priorités établies par les patients, ce qui débouche sur de meilleurs résultats pour les patients." (Instituts de recherche
en santé du Canada)</a>

## Vue générale des étapes de la recherche
Comme les autres projets de recherche, un projet de recherche axé sur le patient comprendra le problème de recherche, les besoins (lacunes dans les connaissances), les objectifs, les questions et les méthodes. Les principales étapes sont les suivantes :

1. Une revue de littérature est effectuée pour découvrir les lacunes dans les connaissances. Ces lacunes dans les connaissances orientent les objectifs et les questions de recherche. 
1. Avant que le projet puisse commencer, il doit recevoir l'approbation éthique du ou des comités d'examen institutionnels appropriés. 
1. Les données sont recueillies et analysées à l'aide de la méthode de recherche appropriée (qualitative, quantitative ou mixte) pour produire des résultats. 
1. Ces résultats sont interprétés, communiqués ou appliqués par les intervenants à l'étape de l'application des connaissances.

<img src="img/research_steps.png" alt="Organigramme des étapes de la recherche : Idée > Revue de littérature > Protocole > Éthique > Collecte de données > Analyse des données > Conclusion/application des connaissances" width="50%" />

*Au-dessus : Aperçu général des étapes de la recherche*.

## Éthique de la recherche
L'éthique constitue des normes de conduite qui distinguent et définissent les comportements qui sont acceptables et ceux qui ne le sont pas ; différentes disciplines, professions et organisations ont des normes de conduite qui correspondent à leurs besoins et objectifs. L'éthique de la recherche correspond aux principes et aux normes qui préviennent l'inconduite (p. ex. fabrication, falsification ou fausse déclaration de données de recherche) et protègent les participants à la recherche.

### Contexte historique
La recherche avec des êtres humains fait partie de la médecine depuis des siècles. Cependant, c'est au XIXe siècle qu'elle est véritablement apparue avec l'adoption de la méthode expérimentale, tant en science qu'en médecine. Au début du XXe siècle, l'idée de mener des recherches avec des êtres humains devenait plus acceptable, bien que la plupart des études aient d'abord été menées sur des animaux. Malheureusement, les recherches en bactériologie menées à la fin du XIXe siècle et au début du XXe siècle en Amérique du Nord et en Europe comportaient des pratiques non éthiques. Bien que les associations médicales et scientifiques aient condamné ces pratiques, cela n'a donné lieu à aucune accusation professionnelle, disciplinaire ou pénale. Ce n'est qu'après la Seconde Guerre mondiale et les procès de Nuremberg que de telles accusations ont été portées. Le verdict rendu par les juges en 1947 comprenait une section intitulée "Expériences médicales admissibles", qui décrivait dix principes à suivre dans la conduite de recherches sur des êtres humains. Connu aujourd'hui sous le nom de "Code de Nuremberg", il affirme comme premier principe que "le consentement volontaire du sujet humain est essentiel". 

### Contexte canadien
Une étape clé pour assurer l'acceptabilité éthique d'un projet de recherche est la tenue d'un examen indépendant (c.-à-d. un examen par une personne autre que les chercheurs participant à l'étude). La première exigence canadienne d'une évaluation indépendante des protocoles de recherche par un comité d'éthique de la recherche (CER) a été énoncée dans les lignes directrices de 1978 du Conseil de recherches médicales. En 1998, le Conseil de recherches médicales (maintenant les Instituts de recherche en santé du Canada - IRSC) et deux autres conseils de recherche fédéraux, le Conseil de recherches en sciences naturelles et en génie (CRSNG) et le Conseil de recherches en sciences humaines (CRSH), ont publié un ensemble de lignes directrices : L'Énoncé de politique des trois conseils : Éthique de la recherche avec des êtres humains (EPTC) pour la recherche avec des êtres humains, quel que soit le domaine de recherche. 

Le <a href="http://ethics.gc.ca/fra/policy-politique_tcps2-eptc2_2018.html" target="_blank">Énoncé de politique des trois conseils : Éthique de la recherche avec des êtres humains – EPTC 2 (2018)</a> réglemente la recherche avec des êtres humains dans tous les domaines scientifiques. Cette politique considère les principes éthiques comme l'expression de la valeur primordiale de la dignité humaine et une « boussole » pour fournir les protections nécessaires aux participants à la recherche tout en répondant aux besoins légitimes de la recherche. 

### Comité d'éthique de la recherche (CER)
Étant donné que les chercheurs ne peuvent plus évaluer seuls l'acceptabilité éthique de leurs projets de recherche, ce mandat est confié à un **Comité d'éthique de la recherche (CER)**. Un CÉR est chargé d'évaluer et d'approuver chaque année tout projet de recherche avec des êtres humains. Les CÉR sont habituellement composés de chercheurs, d'éthiciens, d'avocats et de membres du public, et le mandat premier d'un CÉR d'un établissement (p. ex., université, hôpital) est la protection, la sécurité et le bien-être de tous les participants humains à la recherche menée sous la responsabilité de l'établissement. 

## Références
Creswell JW. Educational research : Planning, conducting and evaluating quantitative and qualitative research. Upper Saddle River, NJ : Prentice Hall ; 2002.

## Ressources supplémentaires
* **<a href="http://cihr-irsc.gc.ca/f/documents/cihr_jargon_buster-fr.pdf" target="_blank">Explication du jargon termes de recherche en santé</a>** : un glossaire élaboré par IRSC qui fournit des définitions en langage courant des termes fréquemment utilisés dans la recherche en santé.

* **<a href="https://www.nccmt.ca/fr/developpement-des-capacites/videos" target="_blank">Centre de collaboration nationale des méthodes et outils (CCNMO)</a>** : vidéos sur les concepts clés liés aux données probantes de la recherche et à la santé publique fondée sur des données probantes de l'un des six Centres de collaboration nationale en santé publique au Canada.

* **<a href="https://www.research4life.org/fr/training/" target="_blank">Research4Life portail de formation</a>** : une plateforme avec des ressources téléchargeables gratuitement pour les chercheurs. La section Compétences en rédaction comprend 10 modules, dont la lecture et l'écriture d'articles scientifiques, la propriété intellectuelle et la bibliographie sur le Web, ainsi que des cahiers d'activités pratiques.

* **<a href="https://www.canada.ca/fr/sante-canada/services/science-recherche/avis-scientifiques-processus-decisionnel/comite-ethique-recherche/ressources-matiere-ethique.html" target="_blank">Ressources en matière d'éthique</a>** : une liste de ressources de Santé Canada et du Comité d'éthique de la recherche de l'Agence de santé publique du Canada (ASPC) 
