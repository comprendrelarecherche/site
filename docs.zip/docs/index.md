# Bienvenue à la plateforme **Comprendre la recherche**
La plateforme **Comprendre la recherche** a pour but d'aider les gens à comprendre les concepts de base de la recherche. Comprendre les concepts de la recherche est connu sous le nom de **littératie en recherche**. Il établit un langage commun entre les patients, les gestionnaires, les cliniciens et les chercheurs qui peuvent collaborer à des projets de recherche.

## Qu'est-ce que la littératie en recherche
**La culture de la recherche** est définie comme étant suffisamment familière avec l'éthique et les méthodes scientifiques pour comprendre les concepts fondamentaux de la recherche (connaissances), respecter l'éthique de la recherche (attitude), et communiquer avec les chercheurs et les participants à la recherche (comportement). Cette définition est adaptée de Nebeker et López-Arenas (2016).

## A qui s'adresse cette plateforme
**Comprendre la recherche** s'adresse aux patients, aux gestionnaires, aux cliniciens et à toute personne intéressée par la recherche et la collaboration avec les chercheurs (intervenants).

## Pourquoi nous avons créé cette plateforme
* Aider les intervenants à comprendre et à utiliser un langage de recherche commun
* Permettre aux équipes de recherche, aux patients et au public de préparer leurs partenariats
* Guider les équipes de recherche, les patients et le public à travers les étapes importantes de la recherche.
* Permettre aux équipes de recherche, aux patients et au public d'avoir accès à plusieurs références externes qui les aideront dans leurs partenariats.

## Comment la plateforme est organisée
La plateforme se compose de **ce site Web** en conjonction avec un <a href="https://osf.io/dwy4c/" target="_blank">**dépôt Open Science Framework (OSF)**</a>. Le site Web fournit du contenu textuel sur la culture de la recherche, tandis que le dépôt de la OSF donne accès au public aux documents de formation que nous avons élaborés, tous disponibles sous une licence Creative Commons. Le dépôt de la OSF contient également un cahier de travail contenant des renseignements détaillés sur chacun des sujets abordés sur ce site Web.

La plateforme est organisée autour des thèmes suivants :

* **Recherche** : Une introduction à la science, à la recherche et à l'éthique.
* **Revue de littérature** : Une introduction aux types d'analyses documentaires et des instructions sur la façon de lire les articles de recherche.
* **Méthodologie** : Explication de la recherche qualitative, quantitative et méthodes mixtes et de l'approche participative.
* **Application des connaissances** : Introduction à la synthèse et à la diffusion des données probantes.

Le dépôt **Open Science Framework** héberge notre matériel de formation sur la culture de la recherche, y compris le :

* Diapositives PowerPoint pour les ateliers de littératie en recherche
* Cahier d'accompagnement pour les participants - <a href="https://osf.io/u79yp/" target="_blank">Télécharger le cahier</a>
* Brèves vidéos expliquant divers concepts - <a href="https://osf.io/bz972/" target="_blank">Voir vidéos</a>


## À propos de nous
La mission de la **<a href="http://unitesoutiensrapqc.ca/composante/developpements-methodologiques/" target="_blank"> Unité de soutien SRAP Québec </a>** est de contribuer à répondre aux besoins des patients et des intervenants du réseau de la santé et des services sociaux par des actions concrètes et de bâtir une masse critique d'expertise méthodologique multidisciplinaire adaptée à ces besoins. 

Au sein de l'Unité de soutien SRAP Québec, on retrouve les composantes **Développements méthodologiques** et **Stratégie de recherche en partenariat avec les patients et le public**. 

Le **<a href="http://unitesoutiensrapqc.ca/composante/developpements-methodologiques/" target="_blank">Composante développements méthodologiques</a>** vise à répondre aux besoins des chercheurs, des patients, des cliniciens et des gestionnaires en matière de méthodes avancées (approches méthodologiques et techniques) pour la planification, la réalisation et l'évaluation de la recherche axée sur les patients. 

L'unité **<a href="http://unitesoutiensrapqc.ca/composante/strategie-de-recherche/" target="_blank">Stratégie de partenariat avec les patients et le public </a>** vise à développer des centres d'expertise partout au Québec selon la méthodologie développée par les quatre Réseau universitaires intégrés en santé (RUIS) du Québec.  

La Stratégie de recherche axée sur le patient (SRAP) a été élaborée en partenariat avec des chercheurs, des cliniciens, des décideurs, des patients, des membres de différentes communautés et des citoyens. 


## Références
Nebeker C, López-Arenas A. Building research integrity and capacity (BRIC) : an educational initiative to increase research literacy among community health workers and promotores. Journal of Microbiology & Biology Education. 2016 Mar;17(1):41.


## Droits d'auteur et utilisation
Ce produit de connaissance intitulé **Comprendre la recherche** est protégé par le droit d'auteur et appartient aux auteurs.

Ce produit de connaissance est disponible sous **<a href="https://creativecommons.org/licenses/by-nc-sa/4.0/" target="_blank">Creative Commons Public License Attribution-NonCommercial-ShareAlike 4.0 International</a>**.

Si vous avez l'intention d'utiliser du matériel de Comprendre la recherche, veuillez nous faire savoir qui vous êtes et comment vous comptez l'utiliser. Cette information est très importante pour nous afin d'évaluer son utilisation et son impact. Vous pouvez nous écrire à **supportunit [dot] fammed [at] mcgill [dot] ca**.

## Commanditaires
Cette initiative est parrainée par <a href="http://unitesoutiensrapqc.ca/composante/developpements-methodologiques/" target="_blank"> Unité de soutien SRAP Québec, Composante développements méthodologiques</a>; le <a href="https://ceppp.ca/fr/" target="_blank">Centre d'excellence sur le partenariat avec les patients et le public (CEPPP)</a>; la <a href="http://unitesoutiensrapqc.ca/composante/strategie-de-recherche/" target="_blank">Stratégie de recherche en partenariat avec les patients et le public</a>, et le <a href="https://www.mcgill.ca/familymed/" target="_blank">Département de médecine de famille de McGill</a>.

<img src="img/Logo-Unite-de-SOUTIEN-SRAP-Quebec-COULEUR.jpg" alt="le logo de l'Unité de Soutien SRAP Québec" height="75" />
<img src="img/thumbnail_CEPPP_logo_web_horiz_COUL_English.png" alt="le logo du Centre d'excellence sur le partenariat avec les patients et le public" height="75" />
<img src="img/Logo_McGill clear.jpg" alt="le logo du Département de médecine de famille de McGill" height="75" />

