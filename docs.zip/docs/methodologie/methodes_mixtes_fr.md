# Recherche de méthodes mixtes

## Que sont les méthodes mixtes
La recherche sur les méthodes mixtes fait référence à la combinaison et à l'intégration de méthodes qualitatives et quantitatives dans une même étude ou recherche.

| | |
| ---- | ---- |
| L'intégration | L'intégration qualitative et quantitative dans le processus de collecte et d'analyse des données est essentielle dans les méthodes mixtes (et non le simple ajout de 2 études distinctes) |
| La stratégie | Les méthodes mixtes sont utilisées lorsque cette stratégie permet aux chercheurs de mieux répondre à une question de recherche |

Lorsqu'une étude qualitative apparaît à côté d'une étude quantitative dans une étude de recherche, il ne s'agit pas nécessairement d'une recherche mixte en soi. En d'autres termes, la recherche sur les méthodes mixtes ne propose pas le simple ajout d'études qualitatives et quantitatives distinctes. La recherche à méthodes mixtes cherche plutôt à intégrer des composantes quantitatives et qualitatives dans la même étude pour répondre à la même question générale de recherche. **L'intégration est donc un élément clé de la recherche sur les méthodes mixtes. Il se réfère au point d'interface entre les composantes quantitatives et qualitatives d'une recherche à méthodes mixtes. 

## Quand utiliser des méthodes mixtes
Des méthodes mixtes sont utilisées lorsqu'il faut intégrer l'information qualitative et quantitative pour mieux répondre aux questions de la recherche. Des méthodes mixtes peuvent être choisies en cas de besoin :

* Interpréter les résultats quantitatifs
* Généraliser statistiquement les résultats qualitatifs
* Explorer (qualitativement) et mesurer (quantitativement) un phénomène

## Méthodes mixtes
Trois méthodes de recherche mixtes de base sont fréquemment observées.

Conception de la recherche | Description | Exemple | 
| ----- | ----- | ----- |
| La conception convergente | La collecte et l'analyse des données qualitatives et quantitatives sont effectuées séparément, puis les résultats des deux sont comparés ou combinés | Par exemple, les chercheurs sont intéressés à comprendre les obstacles et les facilitateurs de la mise en œuvre d'un nouveau programme. Pour atteindre cet objectif, ils décident de mener une enquête auprès des participants (quantitative) et des entrevues avec les cliniciens (qualitative). Ensuite, ils comparent les résultats obtenus pour chaque méthode.  |
| Conception exploratoire séquentielle | La première phase est qualitative. Les résultats qualitatifs éclairent la collecte des données de la deuxième phase, qui est quantitative. | Cette conception peut être utilisée pour développer un outil de mesure. Tout d'abord, des entrevues seront menées pour dresser une liste d'éléments jugés importants par les experts et créer une première version de l'outil de mesure. Ensuite, une étude quantitative est menée pour étudier les propriétés psychométriques de cet outil (ex. analyse factorielle). |
| Conception explicative séquentielle | Dans cette conception, la première phase est quantitative. Les résultats quantitatifs éclairent la collecte de données de la deuxième phase, qui est qualitative. | Une étude quantitative est menée pour étudier l'efficacité d'une intervention. Ensuite, une étude qualitative est menée pour expliquer pourquoi l'intervention n'a pas fonctionné pour certains participants. |

### La conception convergent
<img src="../img/convergent_design.png" alt="Collecte et analyse de données quantitatives + La collecte et l'analyse de données qualitatives sont combinées pour obtenir des résultats qualitatifs et quantitatifs intégrés. Figure adaptée de l'ouvrage de référence de Creswell & Plano Clark (2017)." width="75%" />

*Au-dessus : Diagramme de conception convergente*

### Conception exploratoire séquentielle
<img src="../img/sequential_exploratory_design.png" alt="Phase 1 : Collecte et analyse de données qualitatives > Résultats qualitatifs > Intégration à la phase 2 : Collecte et analyse de données quantitatives. Figure adaptée de l'ouvrage de référence de Creswell & Plano Clark (2017)." width="75%" />

*Au-dessus : Diagramme de la conception exploratoire séquentielle*.

### Conception explicative séquentielle
<img src="../img/sequential_explanatory_design.png" alt="Phase 1 : Collecte et analyse des données quantitatives > Résultats quantitatifs > Intégration dans la phase 2 : Collecte et analyse de données qualitatives. Figure adaptée de l'ouvrage de référence de Creswell & Plano Clark (2017)." width="75%" />

*Au-dessus : Diagramme de la conception explicatif séquentiel*.

## Avantages et défis des méthodes mixtes
Avantages | Défis |
| ----- | ----- |
| Les forces de chaque type de méthode peuvent compenser les limites de l'autre | Le processus de recherche peut être complexe et exiger beaucoup de temps et de ressources |
| La recherche sur les méthodes mixtes permet une compréhension plus complète et plus approfondie du phénomène étudié qu'une approche quantitative ou qualitative seule | Peut potentiellement nécessiter une formation et un équipement supplémentaires (p. ex., logiciels spécialisés) |

La recherche quantitative donne généralement accès à une ou plusieurs explications plus générales et donne des mesures, des descriptions généralisables, des tendances générales (p. ex. analyses statistiques sur un grand groupe de personnes). 

La recherche qualitative donne généralement accès à une compréhension plus approfondie des phénomènes complexes dans un contexte particulier (p. ex. des entrevues individuelles pour comprendre les phénomènes complexes). 

En combinant les deux, la recherche sur les méthodes mixtes peut potentiellement compenser les limites de chaque méthode pour comprendre un phénomène dans ses aspects généraux et spécifiques. 

Les méthodes mixtes permettent une compréhension plus complète et plus approfondie du phénomène à l'étude qu'une approche quantitative ou qualitative utilisée seule. L'idée est qu'en combinant et en intégrant les forces des méthodes qualitatives et quantitatives, il sera possible de mieux expliquer la complexité d'un phénomène. Toutefois, cela exige que les chercheurs ou les équipes de recherche aient une bonne compréhension des méthodes qualitatives et quantitatives.

## Ressources supplémentaires
* **<a href="https://www.youtube.com/watch?v=1OaNiTlpyX8" target="_blank">What is mixed methods research?</a>** : Vidéo YouTube de John Creswell (15 minutes; en anglais)
