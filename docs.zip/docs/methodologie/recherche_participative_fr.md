# Recherche participative

## Qu'est-ce que la recherche participative

« La recherche systématique, avec la collaboration des personnes touchées par la question à l'étude, à des fins d'éducation et d'action ou de changement social » (notre traduction) (Green et al., 1995).

Il y a 4 choses à retenir dans cette définition :

1. La recherche participative implique un partenariat entre les chercheurs universitaires et les personnes qui seront touchées par les résultats ou qui devront les utiliser.
2. La recherche participative est une recherche qui peut utiliser des méthodes quantitatives, qualitatives ou mixtes.
3. Il y a toujours un élément d'apprentissage. Tous les intervenants apprennent quelque chose tout au long du processus de recherche, souvent les uns des autres.
4. La recherche participative implique l'action. Nous n'entreprenons pas des recherches participatives dans le seul but d'apprendre quelque chose. Nous le faisons parce que nous voulons créer un changement. Par exemple, dans le domaine de la recherche participative organisationnelle, nous visons à apporter des changements aux pratiques, comme par exemple, l'amélioration de l'accès aux soins pour les personnes atteintes de démence.

## Ce qui différencie la recherche participative
Les acteurs du partenariat doivent **prendre des décisions ensemble** au moins à ces quatre étapes du processus de recherche :

* Centre d'intérêt de la recherche
* Collecte et/ou analyse des données
* Interprétation des résultats
* Diffusion et/ou mise en œuvre
 
**Dans l'ensemble, nous entreprenons de la recherche participative parce que nous voulons apporter un changement et un partenariat avec un groupe varié d'intervenants peut nous aider à nous assurer que notre travail est pertinent et utilisé.**

## Références
Green LW, Société royale du Canada, BC Consortium for Health Promotion Research. Study of participatory research in health promotion: Review and recommendations for the development of participatory research in health promotion in Canada. 1995. Royal Society of Canada. 
