# Recherche qualitative

## Quand utiliser la recherche qualitative
La recherche qualitative n'est pas utilisée à la place de la recherche quantitative. Elle nous permet de répondre à des questions auxquelles on ne peut pas répondre de la même façon par la recherche quantitative. Les données qualitatives sont recueillies en parlant aux gens, en observant les gens et les situations, et en enregistrant systématiquement nos observations (en prenant des notes, des photographies, des vidéos, etc.). Ainsi, la recherche qualitative nous permet d'acquérir une compréhension approfondie d'un phénomène.

| | Elle est | Elle n'est pas |
| ---- | ---- | ---- |
Objectif | Comprendre un phénomène | Mesurer un phénomène |
| Questions | Quoi ? Comment ? Pourquoi ? | Combien ? Questions avec réponse oui/non |
Données | Mots, images, son(s), interviews, observations | Chiffres, questionnaires, enquête, documents |

## Collecte de données qualitatives
Les données qualitatives sont recueillies de trois façons principales :

* **Entrevues** : Nous parlons avec les gens individuellement ou en groupe, enregistrons nos entrevues et les transcrivons. Ces transcriptions sont les données que nous analysons.
* **Observations** : Nous observons les gens et les situations, et enregistrons systématiquement ces observations par la prise de notes, des photographies, des croquis ou des vidéos.
* **Documents** : Nous recueillons des documents, tels que des courriels, des rapports, des procès-verbaux de réunions, ou tout autre document qui nous fournit des renseignements pour nous aider à répondre à nos questions.

## Transférabilité
Les résultats de la recherche qualitative ne sont pas généralisés à de plus grandes populations. Cela n'est pas possible, notamment parce que les échantillons sont généralement petits. La richesse de la recherche qualitative réside dans le niveau de détail, la profondeur des résultats. 

La transférabilité est  « l'équivalent » qualitatif de la généralisabilité. L'objectif est de présenter les résultats avec suffisamment de détails pour que le lecteur puisse voir s'ils sont transférables dans leur contexte.

## Perspectives et dimensions
Tout le monde ne comprend pas ou ne perçoit pas un phénomène de la même façon. La recherche qualitative nous permet d'examiner les différentes perceptions de ceux qui vivent le phénomène sous différents angles.

## Cadres de référence
Lorsque nous présentons les résultats d'une étude qualitative, l'un de nos objectifs est de nous assurer que notre auditoire comprend le phénomène de la façon dont nous l'entendons. Le cadre de référence que nous utilisons pour analyser et décrire un phénomène peut modifier la façon dont notre public le perçoit.
La recherche qualitative nous permet de comprendre les phénomènes de différentes manières.

## Construction et déconstruction
Pour comprendre un phénomène dans la recherche qualitative, nous pouvons le décomposer en ses nombreux "morceaux" et les assembler de nouvelles façons. Par exemple, dans une étude qualitative, nous distinguons les transcriptions d'entrevues en catégories distinctes. Ce processus d'analyse des données est appelé "codage".

## Ressources supplémentaires
* **<a href="https://www.youtube.com/watch?v=IsAUNs-IoSQ" target="_blank">Overview of qualitative research methods</a>** : Vidéo YouTube (12 minutes; en anglais)
